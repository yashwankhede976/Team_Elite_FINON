# Authentication API - Quick Start Guide

## Setup & Installation

### 1. Verify Dependencies
All required dependencies are already in `requirement.txt`:
- `djangorestframework==3.16.1`
- `djangorestframework_simplejwt==5.5.1`
- `PyJWT==2.10.1`
- `Django==5.2.5`

Install if needed:
```bash
cd d:\FinRight-AI-\backend
pip install -r requirement.txt
```

### 2. Database Migrations
Migrations are already created. Just apply them:
```bash
python manage.py migrate
```

---

## Testing the API

### Method 1: Using cURL (Command Line)

#### Register a User
```bash
curl -X POST "http://127.0.0.1:8000/auth/register/" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser",
    "email": "test@finright.app",
    "password": "TestPass123!",
    "password_confirm": "TestPass123!"
  }'
```

#### Login
```bash
curl -X POST "http://127.0.0.1:8000/auth/login/" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@finright.app",
    "password": "TestPass123!"
  }'
```

Response will include:
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "user": {...}
}
```

#### Get Current User Profile (Protected)
```bash
# Replace with your actual access token
curl -X GET "http://127.0.0.1:8000/auth/me/" \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
```

---

### Method 2: Using Postman

1. **Create Register Request**
   - Method: POST
   - URL: `http://127.0.0.1:8000/auth/register/`
   - Headers: `Content-Type: application/json`
   - Body:
     ```json
     {
       "username": "postman_user",
       "email": "postman@finright.app",
       "password": "PostmanPass123!",
       "password_confirm": "PostmanPass123!"
     }
     ```

2. **Create Login Request**
   - Method: POST
   - URL: `http://127.0.0.1:8000/auth/login/`
   - Body:
     ```json
     {
       "email": "postman@finright.app",
       "password": "PostmanPass123!"
     }
     ```
   - Copy the `access` token from response

3. **Create Protected Endpoint Request**
   - Method: GET
   - URL: `http://127.0.0.1:8000/auth/me/`
   - Headers: `Authorization: Bearer <paste_access_token_here>`

---

### Method 3: Using Python Script

```python
import requests
import json

BASE_URL = "http://127.0.0.1:8000"

# 1. Register
register_data = {
    "username": "python_user",
    "email": "python@finright.app",
    "password": "PythonPass123!",
    "password_confirm": "PythonPass123!"
}

response = requests.post(
    f"{BASE_URL}/auth/register/",
    json=register_data
)
print("Register:", response.status_code, response.json())

# 2. Login
login_data = {
    "email": "python@finright.app",
    "password": "PythonPass123!"
}

response = requests.post(
    f"{BASE_URL}/auth/login/",
    json=login_data
)
login_response = response.json()
access_token = login_response['access']
print("Login:", response.status_code)
print("Access Token:", access_token[:50] + "...")

# 3. Get User Profile (Protected)
headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

response = requests.get(
    f"{BASE_URL}/auth/me/",
    headers=headers
)
print("User Profile:", response.status_code, response.json())

# 4. Refresh Token
refresh_token = login_response['refresh']
refresh_data = {"refresh": refresh_token}

response = requests.post(
    f"{BASE_URL}/auth/refresh/",
    json=refresh_data
)
new_access_token = response.json()['access']
print("New Access Token:", new_access_token[:50] + "...")
```

---

## Running the Server

### Start Development Server
```bash
cd d:\FinRight-AI-\backend
python -m uvicorn core.asgi:application --app-dir . --host 0.0.0.0 --port 8000 --reload
```

The `--reload` flag will restart the server when files change.

### Or with Daphne (Alternative ASGI Server)
```bash
daphne -b 0.0.0.0 -p 8000 -v2 core.asgi:application
```

---

## API Endpoint Summary

| Method | Endpoint | Auth Required | Purpose |
|--------|----------|---------------|---------|
| POST | `/auth/register/` | ❌ No | Create new user account |
| POST | `/auth/login/` | ❌ No | Authenticate user and get tokens |
| GET | `/auth/me/` | ✅ Yes | Get current user profile |
| POST | `/auth/refresh/` | ❌ No | Get new access token |

---

## Using Tokens with Other API Endpoints

Once authenticated, include the access token in all protected API requests:

```bash
# Get documents
curl -X GET "http://127.0.0.1:8000/api/documents/" \
  -H "Authorization: Bearer $ACCESS_TOKEN"

# Create conversation
curl -X POST "http://127.0.0.1:8000/api/conversations/create/" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"document_id": 1}'

# Upload expenses
curl -X POST "http://127.0.0.1:8000/api/ai/expense-upload/" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -F "file=@expenses.pdf"
```

---

## Features Implemented

✅ **User Registration**
- Email validation
- Password strength enforcement
- Duplicate email prevention
- Secure password hashing

✅ **User Login**
- Email-based authentication
- JWT token generation
- Refresh token support
- User active status check

✅ **Protected Endpoints**
- `GET /auth/me/` - Current user profile
- All other endpoints require valid token

✅ **Security Features**
- bcrypt password hashing via Django
- JWT tokens with expiration
- CORS protection
- Rate limiting (100/hour anonymous, 1000/hour authenticated)
- Generic error messages (prevent user enumeration)

✅ **Token Management**
- 30-minute access token lifetime
- 7-day refresh token lifetime
- Automatic token rotation
- Optional token blacklisting

---

## Common Issues & Solutions

### Issue: "Password validation failed"
**Solution:** Password must be:
- At least 8 characters long
- Contain uppercase letters
- Contain lowercase letters
- Contain numbers

Example: `MyPass123!`

### Issue: "Email already exists"
**Solution:** Use a unique email address or login with existing account

### Issue: "Authorization header is missing"
**Solution:** Add header: `Authorization: Bearer <your_token>`

### Issue: "Token expired"
**Solution:** Use the refresh endpoint to get a new access token:
```bash
curl -X POST "http://127.0.0.1:8000/auth/refresh/" \
  -H "Content-Type: application/json" \
  -d '{"refresh": "<refresh_token>"}'
```

---

## Next Steps

1. Start the server with the command above
2. Test all endpoints using one of the three methods
3. Integrate tokens into your frontend application
4. Read `AUTH_API_DOCUMENTATION.md` for comprehensive details
5. Review code in `users/` directory for implementation details

---

## File Structure

```
users/
├── models.py          # Custom User model
├── serializers.py     # Input validation & response serialization
├── views.py           # API views for auth endpoints
├── urls.py            # URL routing
├── auth.py            # JWT utilities & decorators
└── tests.py           # Unit tests

core/
├── settings.py        # JWT & REST framework configuration
├── urls.py            # Project-level URL routing
└── asgi.py            # ASGI application config
```

---

## Production Deployment

Before deploying to production:

1. Set `DEBUG = False` in settings
2. Use strong `SECRET_KEY` (from environment)
3. Set `ALLOWED_HOSTS` properly
4. Enable HTTPS (`SECURE_SSL_REDIRECT = True`)
5. Configure CORS for your frontend domain
6. Add monitoring and logging
7. Consider adding email verification
8. Test rate limiting under load
9. Set up token blacklisting with Redis

See `AUTH_API_DOCUMENTATION.md` for full checklist.

---

## Support & Documentation

- Full API docs: `AUTH_API_DOCUMENTATION.md`
- Manual testing guide: `MANUAL_TEST_GUIDE.md`
- Django REST Framework: https://www.django-rest-framework.org/
- SimpleJWT: https://django-rest-framework-simplejwt.readthedocs.io/
