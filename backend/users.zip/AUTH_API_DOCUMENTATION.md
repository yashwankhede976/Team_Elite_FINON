# Production-Ready Authentication API Documentation

This document describes the JWT-based authentication API for FinRight-AI backend, built with Django REST Framework.

## Overview

The authentication system uses JWT (JSON Web Tokens) for stateless, scalable authentication. Tokens are signed with the Django secret key and include expiration times for security.

- **Access Token**: 30 minutes (for API requests)
- **Refresh Token**: 7 days (to obtain new access tokens)

## Architecture

### Components

1. **Serializers** (`users/serializers.py`)
   - `UserRegisterSerializer`: Validates and creates new users
   - `UserLoginSerializer`: Validates credentials
   - `TokenSerializer`: Formats token response
   - `UserProfileSerializer`: Returns user profile data

2. **Authentication Utilities** (`users/auth.py`)
   - `generate_jwt_tokens()`: Create access/refresh token pair
   - `verify_jwt_token()`: Decode and validate token
   - `get_user_from_token()`: Extract user from token
   - `IsAuthenticated`: Permission class
   - `IsActive`: Permission class for active users only
   - `@jwt_required`: Decorator for function-based views

3. **Views** (`users/views.py`)
   - `RegisterAPIView`: User registration
   - `LoginAPIView`: User authentication
   - `UserProfileAPIView`: Protected user profile
   - `refresh_token_view`: Token refresh endpoint

4. **Models** (`users/models.py`)
   - `User`: Custom user model with email-based authentication

---

## API Endpoints

### Authentication Endpoints

#### 1. Register User
**POST** `/auth/register/`

Creates a new user account.

**Request:**
```bash
curl -X POST "http://127.0.0.1:8000/auth/register/" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john@example.com",
    "password": "SecurePassword123!",
    "password_confirm": "SecurePassword123!"
  }'
```

**Response (201 Created):**
```json
{
  "message": "User registered successfully",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com"
  }
}
```

**Error Responses:**

- **400 Bad Request** - Email already exists:
```json
{
  "email": ["A user with this email address already exists."]
}
```

- **400 Bad Request** - Password mismatch:
```json
{
  "password": ["Password fields didn't match."]
}
```

- **400 Bad Request** - Weak password:
```json
{
  "password": ["This password is too common.", "Password must be at least 8 characters..."]
}
```

---

#### 2. Login User
**POST** `/auth/login/`

Authenticates user and returns JWT tokens.

**Request:**
```bash
curl -X POST "http://127.0.0.1:8000/auth/login/" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "SecurePassword123!"
  }'
```

**Response (200 OK):**
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "user": {
    "id": 1,
    "email": "john@example.com",
    "username": "john_doe",
    "is_active": true
  }
}
```

**Error Responses:**

- **401 Unauthorized** - Invalid credentials:
```json
{
  "detail": "Invalid email or password."
}
```

- **401 Unauthorized** - Inactive user:
```json
{
  "detail": "This user account is inactive."
}
```

---

#### 3. Get User Profile (Protected)
**GET** `/auth/me/`

Returns the current authenticated user's profile.

**Request:**
```bash
curl -X GET "http://127.0.0.1:8000/auth/me/" \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
```

**Response (200 OK):**
```json
{
  "id": 1,
  "email": "john@example.com",
  "username": "john_doe",
  "is_active": true,
  "date_joined": "2025-11-27T10:00:00Z"
}
```

**Error Responses:**

- **401 Unauthorized** - Missing token:
```json
{
  "detail": "Authentication credentials were not provided."
}
```

- **401 Unauthorized** - Invalid token:
```json
{
  "detail": "Given token not valid for any token type"
}
```

- **401 Unauthorized** - Expired token:
```json
{
  "detail": "Token is blacklisted"
}
```

---

#### 4. Refresh Access Token
**POST** `/auth/refresh/`

Generates a new access token using a valid refresh token.

**Request:**
```bash
curl -X POST "http://127.0.0.1:8000/auth/refresh/" \
  -H "Content-Type: application/json" \
  -d '{
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
  }'
```

**Response (200 OK):**
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."
}
```

**Error Responses:**

- **400 Bad Request** - Missing refresh token:
```json
{
  "detail": "Refresh token is required."
}
```

- **401 Unauthorized** - Invalid refresh token:
```json
{
  "detail": "Invalid refresh token: Token is invalid or expired"
}
```

---

## Security Features

### Password Security
- ✅ Uses bcrypt via Django's `make_password()` (via `set_password()`)
- ✅ Password validation enforces strength requirements
- ✅ Minimum 8 characters, mixed case, numbers required
- ✅ Passwords never stored in plaintext, only hashed

### Token Security
- ✅ JWT tokens signed with Django SECRET_KEY (HMAC-SHA256)
- ✅ Tokens include expiration timestamps
- ✅ Access tokens expire after 30 minutes
- ✅ Refresh tokens expire after 7 days
- ✅ Optional token blacklisting for logout
- ✅ Tokens are HttpOnly cookies optional (configure in settings)

### Input Validation
- ✅ Email format validation
- ✅ Email uniqueness check before registration
- ✅ Password confirmation verification
- ✅ User active status check at login
- ✅ Generic error messages prevent user enumeration

### API Security
- ✅ CORS configured for allowed origins
- ✅ Rate limiting enabled (100/hour for anonymous, 1000/hour for users)
- ✅ Permission classes enforce authentication on protected routes
- ✅ CSRF protection enabled by default

---

## Usage Examples

### 1. Complete Authentication Flow

**Step 1: Register**
```bash
curl -X POST "http://127.0.0.1:8000/auth/register/" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "alice",
    "email": "alice@finright.app",
    "password": "MySecurePass123!",
    "password_confirm": "MySecurePass123!"
  }'
```

**Step 2: Login**
```bash
curl -X POST "http://127.0.0.1:8000/auth/login/" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "alice@finright.app",
    "password": "MySecurePass123!"
  }' \
  -o login_response.json
```

**Step 3: Extract and use access token**
```bash
# Save access token from response
ACCESS_TOKEN=$(cat login_response.json | jq -r '.access')

# Use token to access protected resources
curl -X GET "http://127.0.0.1:8000/auth/me/" \
  -H "Authorization: Bearer $ACCESS_TOKEN"
```

---

### 2. Frontend Integration (JavaScript)

```javascript
// Registration
async function register(username, email, password) {
  const response = await fetch('http://127.0.0.1:8000/auth/register/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      username,
      email,
      password,
      password_confirm: password
    })
  });
  
  if (response.ok) {
    const data = await response.json();
    console.log('User registered:', data.user);
  } else {
    const errors = await response.json();
    console.error('Registration failed:', errors);
  }
}

// Login and store tokens
async function login(email, password) {
  const response = await fetch('http://127.0.0.1:8000/auth/login/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password })
  });
  
  if (response.ok) {
    const data = await response.json();
    // Store tokens in localStorage (or secure cookies)
    localStorage.setItem('access_token', data.access);
    localStorage.setItem('refresh_token', data.refresh);
    localStorage.setItem('user', JSON.stringify(data.user));
    console.log('Login successful:', data.user);
  } else {
    const errors = await response.json();
    console.error('Login failed:', errors);
  }
}

// Get current user profile
async function getCurrentUser() {
  const token = localStorage.getItem('access_token');
  
  const response = await fetch('http://127.0.0.1:8000/auth/me/', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    }
  });
  
  if (response.ok) {
    const user = await response.json();
    console.log('Current user:', user);
    return user;
  } else if (response.status === 401) {
    console.error('Token expired or invalid');
    // Attempt token refresh
    await refreshAccessToken();
  }
}

// Refresh access token
async function refreshAccessToken() {
  const refreshToken = localStorage.getItem('refresh_token');
  
  const response = await fetch('http://127.0.0.1:8000/auth/refresh/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ refresh: refreshToken })
  });
  
  if (response.ok) {
    const data = await response.json();
    localStorage.setItem('access_token', data.access);
    console.log('Token refreshed');
  } else {
    console.error('Token refresh failed, please login again');
    // Redirect to login
  }
}
```

---

### 3. Using with Protected API Endpoints

Once authenticated, include the access token in all API requests:

```bash
# Get documents (requires auth)
curl -X GET "http://127.0.0.1:8000/api/documents/" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json"

# Create conversation (requires auth)
curl -X POST "http://127.0.0.1:8000/api/conversations/create/" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"document_id": 1}'
```

---

## Configuration

### In `core/settings.py`

The JWT configuration is pre-set with production-ready defaults:

```python
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=30),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': SECRET_KEY,  # Uses Django's SECRET_KEY
    'AUTH_HEADER_TYPES': ('Bearer',),
}

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
}
```

---

## Customization

### Adjust Token Lifetimes

In `core/settings.py`:
```python
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=1),  # Longer access token
    'REFRESH_TOKEN_LIFETIME': timedelta(days=30),  # Longer refresh token
}
```

### Enable Token Blacklisting (Logout)

```bash
pip install djangorestframework-simplejwt[blacklist]
```

Then add to `INSTALLED_APPS`:
```python
INSTALLED_APPS = [
    ...
    'rest_framework_simplejwt.token_blacklist',
]
```

### Disable Authentication on Specific Endpoints

In views:
```python
from rest_framework.permissions import AllowAny

class PublicView(APIView):
    permission_classes = [AllowAny]
```

---

## Troubleshooting

### Issue: "Authentication credentials were not provided"
- **Cause**: Missing or incorrectly formatted Authorization header
- **Solution**: Ensure header format is `Authorization: Bearer <token>`

### Issue: "Given token not valid for any token type"
- **Cause**: Token is expired or corrupted
- **Solution**: Use refresh endpoint to get new access token

### Issue: "User not found" after login
- **Cause**: User account deleted or authentication failed
- **Solution**: Check user exists in database and retry login

### Issue: Password validation fails
- **Cause**: Password doesn't meet strength requirements
- **Solution**: Use at least 8 characters with uppercase, lowercase, and numbers

---

## Production Deployment Checklist

- [ ] Set `DEBUG = False` in settings
- [ ] Update `SECRET_KEY` with strong random value (use env var)
- [ ] Set `ALLOWED_HOSTS` to your domain
- [ ] Configure `CORS_ALLOWED_ORIGINS` for frontend domain
- [ ] Enable HTTPS and set `SECURE_SSL_REDIRECT = True`
- [ ] Use Redis for token blacklisting (optional)
- [ ] Add logging for authentication failures
- [ ] Monitor rate limits and adjust if needed
- [ ] Test token refresh flow in load testing
- [ ] Implement account lockout after failed login attempts
- [ ] Add email verification for new registrations (optional)
- [ ] Set up 2FA/MFA (optional)

---

## Testing

Run tests:
```bash
python manage.py test users
```

Test endpoints manually:
```bash
bash MANUAL_TEST_GUIDE.md
```

---

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review Django REST Framework docs: https://www.django-rest-framework.org/
3. Review django-rest-framework-simplejwt docs: https://django-rest-framework-simplejwt.readthedocs.io/
