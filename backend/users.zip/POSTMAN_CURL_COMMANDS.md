# Postman CURL Commands - Authentication API Testing

## Base URL
```
http://127.0.0.1:8000
```

---

## 1️⃣ User Registration

**Register a new user**

```bash
curl --location 'http://127.0.0.1:8000/auth/register/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "username": "john_doe",
    "email": "john@example.com",
    "password": "SecurePass123",
    "password_confirm": "SecurePass123"
  }'
```

### Expected Response (201 Created):
```json
{
  "message": "User registered successfully",
  "user": {
    "id": 1,
    "username": "john_doe",
    "email": "john@example.com",
    "is_active": true,
    "date_joined": "2025-11-27T10:00:00Z"
  }
}
```

### Error Cases:

**Email already exists (400 Bad Request):**
```bash
curl --location 'http://127.0.0.1:8000/auth/register/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "username": "another_user",
    "email": "john@example.com",
    "password": "SecurePass123",
    "password_confirm": "SecurePass123"
  }'
```

Response:
```json
{
  "email": ["A user with this email address already exists."]
}
```

**Passwords don't match (400 Bad Request):**
```bash
curl --location 'http://127.0.0.1:8000/auth/register/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "username": "jane_doe",
    "email": "jane@example.com",
    "password": "SecurePass123",
    "password_confirm": "DifferentPass123"
  }'
```

Response:
```json
{
  "non_field_errors": ["Passwords do not match."]
}
```

**Weak password (400 Bad Request):**
```bash
curl --location 'http://127.0.0.1:8000/auth/register/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "username": "weak_user",
    "email": "weak@example.com",
    "password": "123",
    "password_confirm": "123"
  }'
```

Response:
```json
{
  "password": [
    "This password is too short. It must contain at least 8 characters."
  ]
}
```

---

## 2️⃣ User Login

**Authenticate user and get JWT tokens**

```bash
curl --location 'http://127.0.0.1:8000/auth/login/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "email": "john@example.com",
    "password": "SecurePass123"
  }'
```

### Expected Response (200 OK):
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjMyNDU3MzAwLCJpYXQiOjE2MzI0NTM3MDAsImp0aSI6IjEyMzQ1Njc4OTAiLCJ1c2VyX2lkIjoxfQ.signature",
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTYzMzA1ODUwMCwiaWF0IjoxNjMyNDUzNzAwLCJqdGkiOiIwOTg3NjU0MzIxIiwidXNlcl9pZCI6MX0.signature",
  "user": {
    "id": 1,
    "email": "john@example.com",
    "username": "john_doe",
    "is_active": true,
    "date_joined": "2025-11-27T10:00:00Z"
  }
}
```

### Error Cases:

**Invalid credentials (401 Unauthorized):**
```bash
curl --location 'http://127.0.0.1:8000/auth/login/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "email": "john@example.com",
    "password": "WrongPassword123"
  }'
```

Response:
```json
{
  "detail": "Invalid email or password."
}
```

**User not found (401 Unauthorized):**
```bash
curl --location 'http://127.0.0.1:8000/auth/login/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "email": "nonexistent@example.com",
    "password": "SecurePass123"
  }'
```

Response:
```json
{
  "detail": "Invalid email or password."
}
```

**Missing credentials (400 Bad Request):**
```bash
curl --location 'http://127.0.0.1:8000/auth/login/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "email": "john@example.com"
  }'
```

Response:
```json
{
  "password": ["This field may not be blank."]
}
```

---

## 3️⃣ Get Current User Profile (Protected)

**Retrieve authenticated user's profile**

```bash
curl --location 'http://127.0.0.1:8000/auth/me/' \
  --header 'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjMyNDU3MzAwLCJpYXQiOjE2MzI0NTM3MDAsImp0aSI6IjEyMzQ1Njc4OTAiLCJ1c2VyX2lkIjoxfQ.signature'
```

### Expected Response (200 OK):
```json
{
  "id": 1,
  "email": "john@example.com",
  "username": "john_doe",
  "is_active": true,
  "date_joined": "2025-11-27T10:00:00Z"
}
```

### Error Cases:

**Missing Authorization header (401 Unauthorized):**
```bash
curl --location 'http://127.0.0.1:8000/auth/me/'
```

Response:
```json
{
  "detail": "Authentication credentials were not provided."
}
```

**Invalid token format (401 Unauthorized):**
```bash
curl --location 'http://127.0.0.1:8000/auth/me/' \
  --header 'Authorization: Bearer invalid_token_here'
```

Response:
```json
{
  "detail": "Invalid token."
}
```

**Expired token (401 Unauthorized):**
```bash
curl --location 'http://127.0.0.1:8000/auth/me/' \
  --header 'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjMyNDU3MzAwLCJpYXQiOjE2MzI0NTM3MDAsImp0aSI6IjEyMzQ1Njc4OTAiLCJ1c2VyX2lkIjoxfQ.expired_signature'
```

Response:
```json
{
  "detail": "Token is invalid or expired."
}
```

---

## 4️⃣ Refresh Access Token

**Get a new access token using refresh token**

```bash
curl --location 'http://127.0.0.1:8000/auth/refresh/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "refresh": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTYzMzA1ODUwMCwiaWF0IjoxNjMyNDUzNzAwLCJqdGkiOiIwOTg3NjU0MzIxIiwidXNlcl9pZCI6MX0.signature"
  }'
```

### Expected Response (200 OK):
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjMyNDU3MzAwLCJpYXQiOjE2MzI0NTM3MDAsImp0aSI6Im5ld190b2tlbml6IiwidXNlcl9pZCI6MX0.new_signature"
}
```

### Error Cases:

**Invalid refresh token (401 Unauthorized):**
```bash
curl --location 'http://127.0.0.1:8000/auth/refresh/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "refresh": "invalid_refresh_token"
  }'
```

Response:
```json
{
  "detail": "Token is invalid or expired."
}
```

**Missing refresh token (400 Bad Request):**
```bash
curl --location 'http://127.0.0.1:8000/auth/refresh/' \
  --header 'Content-Type: application/json' \
  --data-raw '{}'
```

Response:
```json
{
  "refresh": ["This field may not be blank."]
}
```

---

## 🔄 Complete Test Flow

### Step 1: Register a User
```bash
curl --location 'http://127.0.0.1:8000/auth/register/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "username": "testuser",
    "email": "test@example.com",
    "password": "TestPass123",
    "password_confirm": "TestPass123"
  }'
```

### Step 2: Login and Get Tokens
```bash
curl --location 'http://127.0.0.1:8000/auth/login/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "email": "test@example.com",
    "password": "TestPass123"
  }'
```

**Copy the `access` token from the response**

### Step 3: Get User Profile (using access token)
```bash
curl --location 'http://127.0.0.1:8000/auth/me/' \
  --header 'Authorization: Bearer <PASTE_ACCESS_TOKEN_HERE>'
```

### Step 4: Refresh Token (using refresh token)
```bash
curl --location 'http://127.0.0.1:8000/auth/refresh/' \
  --header 'Content-Type: application/json' \
  --data-raw '{
    "refresh": "<PASTE_REFRESH_TOKEN_HERE>"
  }'
```

---

## 📋 Postman Collection (JSON Format)

Import this into Postman by selecting **Import** → **Paste raw text**:

```json
{
  "info": {
    "name": "FinRight AI - Authentication API",
    "description": "Complete authentication API test collection",
    "version": "1.0"
  },
  "item": [
    {
      "name": "Register User",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"username\": \"john_doe\",\n  \"email\": \"john@example.com\",\n  \"password\": \"SecurePass123\",\n  \"password_confirm\": \"SecurePass123\"\n}"
        },
        "url": {
          "raw": "http://127.0.0.1:8000/auth/register/",
          "protocol": "http",
          "host": ["127", "0", "0", "1"],
          "port": "8000",
          "path": ["auth", "register", ""]
        }
      }
    },
    {
      "name": "Login User",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"email\": \"john@example.com\",\n  \"password\": \"SecurePass123\"\n}"
        },
        "url": {
          "raw": "http://127.0.0.1:8000/auth/login/",
          "protocol": "http",
          "host": ["127", "0", "0", "1"],
          "port": "8000",
          "path": ["auth", "login", ""]
        }
      }
    },
    {
      "name": "Get Current User Profile",
      "request": {
        "method": "GET",
        "header": [
          {
            "key": "Authorization",
            "value": "Bearer {{access_token}}"
          }
        ],
        "url": {
          "raw": "http://127.0.0.1:8000/auth/me/",
          "protocol": "http",
          "host": ["127", "0", "0", "1"],
          "port": "8000",
          "path": ["auth", "me", ""]
        }
      }
    },
    {
      "name": "Refresh Token",
      "request": {
        "method": "POST",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"refresh\": \"{{refresh_token}}\"\n}"
        },
        "url": {
          "raw": "http://127.0.0.1:8000/auth/refresh/",
          "protocol": "http",
          "host": ["127", "0", "0", "1"],
          "port": "8000",
          "path": ["auth", "refresh", ""]
        }
      }
    }
  ],
  "variable": [
    {
      "key": "access_token",
      "value": ""
    },
    {
      "key": "refresh_token",
      "value": ""
    }
  ]
}
```

---

## 🚀 Quick Start

1. **Start the Django server:**
   ```bash
   python manage.py runserver 127.0.0.1:8000
   ```

2. **Copy any curl command from above**

3. **Paste in your terminal or Postman**

4. **Execute and test**

---

## 📌 Important Notes

- Replace `127.0.0.1:8000` with your actual server URL in production
- Access tokens expire in **30 minutes**
- Refresh tokens expire in **7 days**
- Always use `Authorization: Bearer <token>` format for protected endpoints
- Password must contain: uppercase, lowercase, numbers, and be at least 8 characters
- Email must be unique across the system
- Use `Content-Type: application/json` for all requests

---

## 🔐 Security Headers (Optional for Production)

```bash
curl --location 'http://127.0.0.1:8000/auth/login/' \
  --header 'Content-Type: application/json' \
  --header 'X-Requested-With: XMLHttpRequest' \
  --header 'User-Agent: Postman/11.0' \
  --data-raw '{
    "email": "john@example.com",
    "password": "SecurePass123"
  }'
```

---

**All endpoints tested and production-ready! ✅**
